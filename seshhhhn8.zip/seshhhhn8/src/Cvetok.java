public class Cvetok {
    private String Name;
    private int  Smell;
    private double price;

//    String Name;
//    int Smell;
//    double price;


    public Cvetok(String Name,int Smell,double price){
        this.Name=Name;
        this.Smell=Smell;
        this.price=price;
    }
    public double getPrice() {
        return price;
    }
}
