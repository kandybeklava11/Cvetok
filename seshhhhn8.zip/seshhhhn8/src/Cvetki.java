public class Cvetki {

    private String Name;
    private int Smell;
    private double price;

//    String Name;
//    int Smell;
//    double price;


    public Cvetki(String Name, int Smell, double price) {
        this.Name = Name;
        this.Smell = Smell;
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return Name;
    }
    public int getSmell() {
        return Smell;
    }
    public static double costMostExpen(Cvetki[] cvetok) {
        double MaxCost = Double.MIN_VALUE;
        for (Cvetki cvetki : cvetok) {
            if (cvetki.getPrice() > MaxCost) {
                MaxCost = cvetki.getPrice();
            }
        }
        return MaxCost;
    }
}


