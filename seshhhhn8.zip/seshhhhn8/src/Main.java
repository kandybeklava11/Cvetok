import java.util.Arrays;
import java.util.Comparator;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        //5 person
/*
        Person person1 = new Person("Janara", 56, "female");
        Person person2 = new Person("alkula", 34, "female");
        Person person3 = new Person("Bazar", 12, "male");
        Person person4 = new Person("jumush", 3, "male");
        Person person5 = new Person("dariya", 67, "female");
        Person[] array1 = {person1, person2, person3, person4, person5};
        System.out.println(minNumber(array1));
        System.out.println(maxNumber(array1));

    }

    public static Person minNumber(Person[] array1) {
        Person person = array1[0];
        for (int i = 0; i < array1.length; i++) {
            if (array1[i].age < person.age) {
                person = array1[i];
            }
        }
        return person;
    }

    public static Person maxNumber(Person[] array1) {
        Person person = array1[0];
        for (int i = 0; i < array1.length; i++) {
            if (array1[i].age > person.age) {
                person = array1[i];
            }
        }
        return person;

 */
        Cvetki[] cvetok = {
                new Cvetki("Tulpan", 10, 100),
                new Cvetki("Rose", 23, 150),
                new Cvetki("Romashka", 15, 80),
        };
        System.out.println("-----------------------------------------------");
        for (Cvetki cvetki : cvetok) {
            System.out.println("Цветок : " + cvetki.getName() + ", свежесть: " + cvetki.getSmell() + ", цена: " + cvetki.getPrice());
        }
        double mostExprn = Arrays.stream(cvetok)
                .max(new Comparator<Cvetki>() {
                    @Override
                    public int compare(Cvetki cvetki1, Cvetki cvetki2) {
                        return Double.compare(cvetki1.getPrice(), cvetki2.getPrice());
                    }
                })
                .get().getPrice();
        System.out.println("-----------------------------------------------");

        System.out.println("Цена самого дорогого цветка: " +mostExprn);

        Arrays.sort(cvetok, Comparator.comparingInt(Cvetki::getSmell));
        System.out.println();

        System.out.println("Отсортированный массив цветов по свежести:");
        for (Cvetki cvetki : cvetok) {
            System.out.println("Цветок: " + cvetki.getName() + ", свежесть: " + cvetki
                    .getSmell() + ", цена: " + cvetki.getPrice());
        }
    }
}







