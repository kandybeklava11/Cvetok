public class Person {
    //5 person
/*
    String FullName;
    int age;
    String Gender;

    @Override
    public String toString() {
        return "Person{" +
                "FullName='" + FullName + '\'' +
                ", age=" + age +
                ", Gender='" + Gender + '\'' +
                '}';
    }

    public Person(String fullName, int age, String gender) {
        FullName = fullName;
        this.age = age;
        Gender = gender;
    }

 */

}

